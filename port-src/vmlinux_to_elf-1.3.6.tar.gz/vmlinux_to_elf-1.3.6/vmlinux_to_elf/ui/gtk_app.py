#!/usr/bin/env python3
# -*- encoding: Utf-8 -*-
from os import stat, scandir, environ, makedirs, access, remove, W_OK
from os.path import dirname, realpath, exists, expanduser, join
from importlib.metadata import version
from argparse import ArgumentParser
from typing import Optional, List
from io import BytesIO, StringIO
from shutil import which, copy2
from threading import Thread
from sys import stderr, argv
from subprocess import run
import logging

from vmlinux_to_elf.core.auto_unpack import (
    VmlinuzDecompressor,
    DecompressOperation,
    DecompressOperationType,
)
from vmlinux_to_elf.ui.recovered_symbol_row import RecoveredSymbolRow
from vmlinux_to_elf.ui.detected_token_row import DetectedTokenRow
from vmlinux_to_elf.core.elf_symbolizer import ElfSymbolizer
from vmlinux_to_elf.core.kallsyms import (
    KallsymsFinder,
    KallsymsNotFoundException,
)
from vmlinux_to_elf.core.architecture_detecter import (
    ArchitectureGuessError,
    ElfMachine,
)

import gi

gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')

from gi.repository import Gtk, GLib, Gdk, Adw, Gio

SCRIPT_DIR = dirname(realpath(__file__))
ASSETS_DIR = realpath(SCRIPT_DIR + '/assets')
RESOURCES_PATH = realpath(ASSETS_DIR + '/vmlinux-to-elf.gresource')

APP_ID = 're.fossplant.vmlinux-to-elf'

# Based on https://github.com/Taiko2k/GTK4PythonTutorial?tab=readme-ov-file#ui-from-graphical-designer

try:
    import gi
except ImportError:
    exit(
        '[!] Please set up the package including the "gui" '
        + 'UV extra (see README)'
    )

gi.require_version('Gtk', '4.0')
gi.require_version('Gdk', '4.0')
gi.require_version('Adw', '1')


class KallsymsLogHandler(logging.Handler):
    def __init__(self, text_buffer: Gtk.TextBuffer):
        logging.Handler.__init__(self)
        self.text_buffer = text_buffer
        self.raw_log = ''

    def emit(self, record: logging.LogRecord):
        self.raw_log += self.format(record) + '\n'

        def cb():
            self.text_buffer.set_text(self.raw_log)

        GLib.idle_add(cb)

    def flush(self):
        self.raw_log = ''

        def cb():
            self.text_buffer.set_text(self.raw_log)

        GLib.idle_add(cb)


def _trim_path(path: str) -> str:
    if path.startswith('/run/user'):  # Flatpak-sandboxed path
        path = path.split('/').pop()
    return path


class MyApp(Adw.Application):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        theme = Gtk.IconTheme.get_for_display(Gdk.Display.get_default())
        theme.add_resource_path('/re/fossplant/vmlinux-to-elf/')

        theme = Gtk.CssProvider.new()
        theme.load_from_resource('/re/fossplant/vmlinux-to-elf/style.css')

        self.connect('open', self.on_open)
        self.connect('startup', self.on_startup)
        self.connect('activate', self.on_activate)

    def on_open(self, app, files, *args):
        if len(files) >= 1:

            def load_bytes_cb(source, result, *args):
                try:
                    data: bytes = (
                        files[0].load_bytes_finish(result)[0].get_data()
                    )
                except GLib.GError as err:
                    dialog = Adw.AlertDialog.new(
                        'Could not read file', err.message
                    )
                    dialog.add_response('ok', 'Ok')
                    dialog.set_default_response('ok')
                    dialog.set_close_response('ok')
                    dialog.choose(self.window, None, None)
                else:
                    self.window.update_kernel_path(
                        _trim_path(files[0].get_path()),
                        data,
                    )

            files[0].load_bytes_async(None, load_bytes_cb)

    def on_startup(self, app, *args):
        self.window = MyWindow()
        self.window.set_application(self)

        # Application will close once it no longer has active windows attached to it

        self.window.present()

    def on_activate(self, app):
        self.window.present()


# Create a templated window object, in order
# to parse the Cambalache-produced UI file

if (
    access(RESOURCES_PATH, W_OK)
    and which('glib-compile-resources')
    and max(meta.stat().st_mtime for meta in scandir(ASSETS_DIR))
    > stat(RESOURCES_PATH).st_mtime
):
    run(['glib-compile-resources', RESOURCES_PATH + '.xml'], cwd=ASSETS_DIR)

Gio.resources_register(Gio.resource_load(RESOURCES_PATH))


@Gtk.Template(resource_path='/re/fossplant/vmlinux-to-elf/gui.ui')
class MyWindow(Adw.ApplicationWindow):
    __gtype_name__ = 'MainWindow'
    kernel_path: Optional[str] = None
    raw_kernel: Optional[VmlinuzDecompressor] = None
    kallsyms: Optional[KallsymsFinder] = None
    guessed_base_address: Optional[int] = None
    guessed_bitness: Optional[bool] = None
    did_user_mod_trigger: bool = False

    detect_symbols_bar: Gtk.ActionBar = Gtk.Template.Child()
    about_dialog: Adw.AboutDialog = Gtk.Template.Child()
    e_machine_combo: Adw.ComboRow = Gtk.Template.Child()
    file_picker_button: Adw.ActionRow = Gtk.Template.Child()
    selection_spinner_row: Adw.PreferencesRow = Gtk.Template.Child()
    kallsyms_debug_buffer: Gtk.TextBuffer = Gtk.Template.Child()
    hex_buffer: Gtk.TextBuffer = Gtk.Template.Child()
    offset_selection_split_view: Adw.OverlaySplitView = Gtk.Template.Child()
    kernel_string_row: Adw.PreferencesRow = Gtk.Template.Child()
    unpacking_row: Adw.PreferencesRow = Gtk.Template.Child()
    unpacking_row_button: Gtk.Button = Gtk.Template.Child()
    decompression_row: Adw.PreferencesRow = Gtk.Template.Child()
    decompression_row_button: Gtk.Button = Gtk.Template.Child()
    analysis_options: Adw.PreferencesGroup = Gtk.Template.Child()
    bitness_switch: Adw.SwitchRow = Gtk.Template.Child()
    base_address_entry: Adw.EntryRow = Gtk.Template.Child()
    bss_size_entry: Adw.SpinRow = Gtk.Template.Child()
    offsets_page: Adw.NavigationPage = Gtk.Template.Child()
    offsets_page_multi_layout: Adw.MultiLayoutView = Gtk.Template.Child()
    offsets_page_wait_spinner: Adw.StatusPage = Gtk.Template.Child()
    wait_spinner: Adw.StatusPage = Gtk.Template.Child()
    file_offset_entry: Adw.EntryRow = Gtk.Template.Child()
    force_absolute_base_switch: Adw.SwitchRow = Gtk.Template.Child()
    symbol_table_selection_model: Gtk.SelectionModel = Gtk.Template.Child()
    symbol_table_model: Gio.ListStore = Gtk.Template.Child()
    offset_list_selection_model: Gtk.SelectionModel = Gtk.Template.Child()
    main_page_toast: Adw.ToastOverlay = Gtk.Template.Child()
    offset_list_model: Gio.ListStore = Gtk.Template.Child()
    application_menu: Gio.Menu = Gtk.Template.Child()
    recent_files_menu: Gio.Menu = Gtk.Template.Child()
    offset_page_toast: Adw.ToastOverlay = Gtk.Template.Child()
    navigation: Adw.NavigationView = Gtk.Template.Child()

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        # Log info to display in the Gtk.TextBuffer present in UI flow
        # screen #2

        logger = logging.getLogger()

        self.handler = KallsymsLogHandler(self.kallsyms_debug_buffer)
        self.handler.setLevel(logging.INFO)
        logger.addHandler(self.handler)

        # Set the architecture ListModel into the Adw.ComboRow for the
        # architecture list

        self.init_arch_list()

        # List recent files

        num_recent_files = 0
        for item in Gtk.RecentManager.get_default().get_items():
            if item.has_application(APP_ID) and item.exists():
                self.recent_files_menu.append(
                    item.get_uri_display(),
                    'win.open-recent(%s)' % repr(item.get_uri()),
                )
                num_recent_files += 1
                if num_recent_files >= 10:
                    break
        if num_recent_files == 0:
            self.application_menu.remove(0)

        # Connect UI actions

        self.connect_actions()
        self.detect_symbols_bar.set_revealed(False)

    def connect_actions(self):

        def show_about(*args):
            self.about_dialog.set_version(version('vmlinux_to_elf'))
            self.about_dialog.present(self)

        self.add_simple_action('show-about', show_about)

        def validate_manual_options(*args):
            try:
                stuff_has_changed = (
                    int(self.file_offset_entry.get_text().strip(), 16) != 0
                    or int(self.base_address_entry.get_text().strip(), 16)
                    != self.guessed_base_address
                    or self.guessed_bitness != self.bitness_switch.get_active()
                    or self.force_absolute_base_switch.get_active()
                )
            except ValueError:
                toast = Adw.Toast.new(
                    'Please specify address and offset '
                    + 'information in hexadecimal form only'
                )
                toast.set_timeout(10)
                self.main_page_toast.add_toast(toast)
                return
            else:
                self.navigation.push_by_tag('offsets_page')
            if stuff_has_changed or self.did_user_mod_trigger:
                # Display spinner

                self.offsets_page.set_can_pop(False)
                self.offsets_page_multi_layout.set_layout_name(
                    'offsets_page_wait_layout'
                )
                self.offsets_page_wait_spinner.set_paintable(
                    Adw.SpinnerPaintable.new(self.offsets_page_wait_spinner)
                )

                # Update kernel metadata

                self.update_kernel_path(
                    self.kernel_path,
                    self.kernel_orig_data,
                    self.bitness_switch.get_active(),
                    self.force_absolute_base_switch.get_active(),
                    int(self.base_address_entry.get_text().strip(), 16),
                    int(self.file_offset_entry.get_text().strip(), 16),
                    True,
                )

        self.add_simple_action(
            'validate-manual-options', validate_manual_options
        )

        def load_bytes_cb(open_result, result):
            try:
                data: bytes = open_result.load_bytes_finish(result)[
                    0
                ].get_data()
            except GLib.GError as err:
                self.selection_spinner_row.set_visible(False)
                dialog = Adw.AlertDialog.new(
                    'Could not read file', err.message
                )
                dialog.add_response('ok', 'Ok')
                dialog.set_default_response('ok')
                dialog.set_close_response('ok')
                dialog.choose(self, None, None)
            else:
                self.update_kernel_path(
                    _trim_path(open_result.get_path()),
                    data,
                )

        def open_recent(action, initial_uri):
            initial_uri = initial_uri.get_string()

            file = Gio.File.new_for_uri(initial_uri)

            self.kernel_string_row.set_visible(False)
            self.unpacking_row.set_visible(False)
            self.decompression_row.set_visible(False)
            self.analysis_options.set_visible(False)
            self.detect_symbols_bar.set_revealed(False)

            self.selection_spinner_row.set_visible(True)
            file.load_bytes_async(None, load_bytes_cb)

        self.add_simple_action(
            'open-recent', open_recent, GLib.VariantType.new('s')
        )

        def pick_file(*args):

            def file_picked(file_dialog: Gtk.FileDialog, task: Gio.Task):
                try:
                    open_result: Gio.File = file_dialog.open_finish(task)
                    Gtk.RecentManager.get_default().add_item(
                        open_result.get_uri()
                    )

                except GLib.GError as err:
                    if err.message != 'Dismissed by user':
                        dialog = Adw.AlertDialog.new(
                            'Could not open file', err.message
                        )
                        dialog.add_response('ok', 'Ok')
                        dialog.set_default_response('ok')
                        dialog.set_close_response('ok')
                        dialog.choose(self, None, None)
                else:
                    self.kernel_string_row.set_visible(False)
                    self.unpacking_row.set_visible(False)
                    self.decompression_row.set_visible(False)
                    self.analysis_options.set_visible(False)
                    self.detect_symbols_bar.set_revealed(False)

                    self.selection_spinner_row.set_visible(True)
                    open_result.load_bytes_async(None, load_bytes_cb)

            file_picker = Gtk.FileDialog()
            # file_picker.set_filters(Gio.ListStore())
            file_picker.open(self, callback=file_picked)

        self.add_simple_action('pick-file', pick_file)

        def copy_debug_information(*args):
            clipboard = Gdk.Display.get_default().get_clipboard()
            clipboard.set(self.handler.raw_log)
            toast = Adw.Toast.new('Debug information copied to clipboard')
            toast.set_timeout(3)
            self.offset_page_toast.add_toast(toast)

        self.add_simple_action(
            'copy-debug-information', copy_debug_information
        )

        def copy_offset_information(*args):
            raw_text = ''
            for index in range(self.offset_list_model.get_n_items()):
                item = self.offset_list_model.get_item(index)
                raw_text += '%s: %s\n' % (item.token, item.offset)
            clipboard = Gdk.Display.get_default().get_clipboard()
            clipboard.set(raw_text)
            toast = Adw.Toast.new('Offset information copied to clipboard')
            toast.set_timeout(3)
            self.offset_page_toast.add_toast(toast)

        self.add_simple_action(
            'copy-offset-information', copy_offset_information
        )

        def export_raw_kernel(*args):

            def confirm_callback(
                alert_dialog: Adw.AlertDialog, result: Gio.AsyncResult
            ):

                if alert_dialog.choose_finish(result) == 'yes':

                    def file_picked(
                        file_dialog: Gtk.FileDialog, task: Gio.Task
                    ):
                        try:
                            open_result: Gio.File = file_dialog.save_finish(
                                task
                            )
                        except GLib.GError as err:
                            if err.message != 'Dismissed by user':
                                dialog = Adw.AlertDialog.new(
                                    'Could not open file', err.message
                                )
                                dialog.add_response('ok', 'Ok')
                                dialog.set_default_response('ok')
                                dialog.set_close_response('ok')
                                dialog.choose(self, None, None)
                        else:
                            try:
                                open_result.replace_contents(
                                    self.raw_kernel.decompressed,
                                    None,
                                    False,
                                    Gio.FileCreateFlags.NONE,
                                    None,
                                )

                            except GLib.GError as err:
                                dialog = Adw.AlertDialog.new(
                                    'Could not write file', err.message
                                )

                                dialog.add_response('ok', 'Ok')
                                dialog.set_default_response('ok')
                                dialog.set_close_response('ok')
                                dialog.choose(self, None, None)

                            else:
                                toast = Adw.Toast.new(
                                    'Correctly exported raw kernel to "%s"'
                                    % _trim_path(open_result.get_path())
                                )
                                toast.set_timeout(10)
                                self.main_page_toast.add_toast(toast)

                    file_picker = Gtk.FileDialog()
                    file_picker.set_initial_name(
                        self.kernel_path.split('/').pop() + '-vmlinux.bin'
                    )
                    file_picker.save(self, callback=file_picked)

            dialog = Adw.AlertDialog.new(
                "This button won't export the symbolized kernel, just the "
                + 'decompressed and unpacked kernel',
                'In order to export a symbolized kernel, you should instead '
                + 'first click the "Find symbol table" button below. '
                + 'Do you want to proceed still?',
            )
            dialog.add_response('yes', 'Yes')
            dialog.add_response('cancel', 'Cancel')
            dialog.set_default_response('yes')
            dialog.set_close_response('cancel')
            dialog.choose(self, None, confirm_callback)

        self.add_simple_action('export-raw-kernel', export_raw_kernel)

        def generate_elf_file(*args):

            def file_picked(file_dialog: Gtk.FileDialog, task: Gio.Task):
                try:
                    open_result: Gio.File = file_dialog.save_finish(task)
                except GLib.GError as err:
                    if err.message != 'Dismissed by user':
                        dialog = Adw.AlertDialog.new(
                            'Could not open file', err.message
                        )
                        dialog.add_response('ok', 'Ok')
                        dialog.set_default_response('ok')
                        dialog.set_close_response('ok')
                        dialog.choose(self, None, None)
                else:
                    self.navigation.push_by_tag('loading_page')
                    self.wait_spinner.set_paintable(
                        Adw.SpinnerPaintable.new(self.wait_spinner)
                    )

                    def processing_thread(*args):

                        data = BytesIO()
                        ElfSymbolizer(
                            self.raw_kernel.decompressed,
                            None,
                            data,
                            elf_machine=ElfMachine[
                                self.e_machine_combo.get_selected_item().get_string()
                            ],
                            bit_size=64
                            if self.bitness_switch.get_active()
                            else 32,
                            base_address=int(
                                self.base_address_entry.get_text().strip(), 16
                            ),
                            bss_size=int(self.bss_size_entry.get_value()),
                            file_offset=int(
                                self.file_offset_entry.get_text().strip(), 16
                            ),
                            override_relative=self.force_absolute_base_switch.get_active(),
                        )

                        def processing_done(*args):

                            if (
                                self.navigation.get_visible_page_tag()
                                == 'loading_page'
                            ):
                                self.navigation.pop()

                            try:
                                open_result.replace_contents(
                                    data.getvalue(),
                                    None,
                                    False,
                                    Gio.FileCreateFlags.NONE,
                                    None,
                                )

                            except GLib.GError as err:
                                dialog = Adw.AlertDialog.new(
                                    'Could not write file', err.message
                                )

                            else:
                                dialog = Adw.AlertDialog.new(
                                    'Kernel successfully wrote', None
                                )
                            dialog.add_response('ok', 'Ok')
                            dialog.set_default_response('ok')
                            dialog.set_close_response('ok')
                            dialog.choose(self, None, None)

                        GLib.idle_add(processing_done)

                    thread = Thread(target=processing_thread)
                    thread.daemon = True
                    thread.start()

            file_picker = Gtk.FileDialog()
            file_picker.set_initial_name(
                self.kernel_path.split('/').pop() + '-vmlinux.elf'
            )
            file_picker.save(self, callback=file_picked)

        self.add_simple_action('generate-elf-file', generate_elf_file)

        def export_symbols(*args):

            def file_picked(file_dialog: Gtk.FileDialog, task: Gio.Task):
                try:
                    open_result: Gio.File = file_dialog.save_finish(task)
                except GLib.GError as err:
                    if err.message != 'Dismissed by user':
                        dialog = Adw.AlertDialog.new(
                            'Could not open file', err.message
                        )
                        dialog.add_response('ok', 'Ok')
                        dialog.set_default_response('ok')
                        dialog.set_close_response('ok')
                        dialog.choose(self, None, None)
                else:
                    self.navigation.push_by_tag('loading_page')
                    self.wait_spinner.set_paintable(
                        Adw.SpinnerPaintable.new(self.wait_spinner)
                    )

                    def processing_thread(*args):

                        out_buffer = StringIO()
                        self.kallsyms.print_symbols_debug(out_buffer)

                        out_buffer = out_buffer.getvalue().encode('utf-8')

                        def processing_done(*args):

                            if (
                                self.navigation.get_visible_page_tag()
                                == 'loading_page'
                            ):
                                self.navigation.pop()

                            try:
                                open_result.replace_contents(
                                    out_buffer,
                                    None,
                                    False,
                                    Gio.FileCreateFlags.NONE,
                                    None,
                                )

                            except GLib.GError as err:
                                dialog = Adw.AlertDialog.new(
                                    'Could not write file', err.message
                                )

                            else:
                                dialog = Adw.AlertDialog.new(
                                    'Symbols file successfully wrote', None
                                )
                            dialog.add_response('ok', 'Ok')
                            dialog.set_default_response('ok')
                            dialog.set_close_response('ok')
                            dialog.choose(self, None, None)

                        GLib.idle_add(processing_done)

                    thread = Thread(target=processing_thread)
                    thread.daemon = True
                    thread.start()

            file_picker = Gtk.FileDialog()
            file_picker.set_initial_name(
                self.kernel_path.split('/').pop() + '-symbols.txt'
            )
            file_picker.save(self, callback=file_picked)

        self.add_simple_action('export-symbols', export_symbols)

    def add_simple_action(
        self, name, callback, param_type: Optional[GLib.VariantType] = None
    ):

        action = Gio.SimpleAction.new(name, param_type)
        action.connect('activate', callback)
        self.add_action(action)

    def init_arch_list(self):

        e_machine_model = Gtk.StringList()

        for e_machine in ElfMachine:
            e_machine_model.append(e_machine.name)

        self.e_machine_combo.set_model(e_machine_model)

    @Gtk.Template.Callback()
    def token_row_activated(self, *args):
        item: DetectedTokenRow = (
            self.offset_list_selection_model.get_selected_item()
        )
        text_buffer = '\nData for "%s" at %s:\n\n' % (item.token, item.offset)
        fd = BytesIO(self.kallsyms.kernel_img)
        fd.seek(int(item.offset, 16))

        subst_chars = ''.join(
            j if j.isprintable() else '.'
            for j in bytes(range(256)).decode('ibm850')
        )

        for i in range(100):
            buf = fd.read(8)
            for char in buf:
                text_buffer += '%02x ' % char
            text_buffer += ' '
            for char in buf:
                text_buffer += subst_chars[char]
            text_buffer += '\n'

        self.hex_buffer.set_text(text_buffer)
        self.offset_selection_split_view.set_show_sidebar(True)

    def update_kernel_path(
        self,
        path: Optional[str],
        orig_data: Optional[bytes] = None,
        is_64_bits: Optional[bool] = None,
        override_relative_base: bool = False,
        override_base_address: Optional[int] = None,
        override_file_offset: int = 0,
        user_mod_trigger: bool = False,
    ):

        if not path:
            return

        self.did_user_mod_trigger = user_mod_trigger

        self.kernel_path = path
        if orig_data:
            self.kernel_orig_data = orig_data

        self.file_picker_button.set_title('Kernel blob')
        self.file_picker_button.set_subtitle(path)

        self.kernel_string_row.set_visible(False)
        self.unpacking_row.set_visible(False)
        self.decompression_row.set_visible(False)
        self.analysis_options.set_visible(False)
        self.detect_symbols_bar.set_revealed(False)

        self.selection_spinner_row.set_visible(True)

        def detection_thread():

            bit_size = None
            if is_64_bits is not None:
                bit_size = 64 if is_64_bits else 32

            self.handler.flush()
            try:
                self.raw_kernel = VmlinuzDecompressor(
                    self.kernel_orig_data[override_file_offset:]
                )

                self.kallsyms = KallsymsFinder(
                    self.raw_kernel.decompressed,
                    bit_size,
                    override_relative_base,
                    override_base_address,
                )

            except ArchitectureGuessError:

                def update_ui_unknown_arch_cb(*args):

                    def bitness_pick_cb(source_obj, res, *args):
                        if dialog.choose_finish(res) == '32-bit':
                            self.update_kernel_path(path, None, False)
                        else:
                            self.update_kernel_path(path, None, True)

                    dialog = Adw.AlertDialog.new(
                        'The architecture of your kernel could not be guessed '
                        + 'successfully',
                        'Is your kernel 32-bit or 64-bit?',
                    )
                    dialog.add_response('32-bit', '32-bit')
                    dialog.add_response('64-bit', '64-bit')
                    dialog.set_default_response('32-bit')
                    dialog.set_close_response('32-bit')
                    dialog.choose(
                        self,
                        None,
                        bitness_pick_cb,
                    )

                GLib.idle_add(update_ui_unknown_arch_cb)

                raise

            except (
                ValueError,
                KallsymsNotFoundException,
                Exception,
            ) as err:
                # TODO Do actual error handling for all Python exceptions too?

                def update_ui_invalid_file_cb(err):

                    self.kernel_string_row.set_visible(False)
                    self.unpacking_row.set_visible(False)
                    self.decompression_row.set_visible(False)
                    self.analysis_options.set_visible(False)
                    self.detect_symbols_bar.set_revealed(False)

                    self.navigation.pop_to_tag('main_page')

                    dialog = Adw.AlertDialog.new(
                        'Could not open kernel', str(err)
                    )
                    dialog.add_response('ok', 'Ok')
                    dialog.set_default_response('ok')
                    dialog.set_close_response('ok')
                    dialog.choose(self, None, None)

                GLib.idle_add(update_ui_invalid_file_cb, err)

                raise

            else:
                # Set and show metadata

                def update_ui_cb(*args):
                    # Display the kernel version string

                    self.kernel_string_row.set_visible(True)
                    self.kernel_string_row.set_subtitle(
                        self.kallsyms.version_string
                    )

                    # Display the "Analysis options" UI block

                    self.analysis_options.set_visible(True)

                    # Evaluate the decompressor_output

                    packing_layers: List[DecompressOperation] = []
                    compression_layers: List[DecompressOperation] = []

                    for op in self.raw_kernel.operations_done:
                        if op.op_type == DecompressOperationType.Unpacking:
                            packing_layers.append(op)
                        elif op.op_type == DecompressOperationType.Restoring:
                            packing_layers.insert(0, op)
                        elif (
                            op.op_type == DecompressOperationType.Decompression
                        ):
                            compression_layers.append(op)
                        else:
                            raise NotImplementedError

                    # Show guessed packing format, if any

                    if packing_layers:
                        self.unpacking_row_button.set_visible(
                            not compression_layers
                        )
                        text = ' | '.join(map(str, packing_layers))
                        self.unpacking_row.set_subtitle(text)
                        # TODO handle "Export raw action"
                        self.unpacking_row.set_activatable(
                            not compression_layers
                        )
                        self.unpacking_row.set_visible(True)

                    # Show guessed compression format, if any

                    if compression_layers:
                        text = ' | '.join(map(str, compression_layers))
                        self.decompression_row.set_subtitle(text)
                        # TODO handle "Export raw action"
                        self.decompression_row.set_visible(True)

                    # Show guessed architecture

                    """
                    key = (
                        architecture_to_readable_name[
                            self.kallsyms.architecture
                        ]
                        if self.kallsyms.architecture
                        else 'Unknown'
                    )

                    self.architecture_combo.set_title(
                        'Architecture preset (auto-detect: %s)' % key
                    )
                    key = self.architecture_combo.get_model().find(key)
                    if key is not None:
                        self.architecture_combo.set_selected(key)
                    """

                    # Show guessed ELF Machine

                    key = (
                        ElfMachine(self.kallsyms.elf_machine).name
                        if self.kallsyms.elf_machine
                        else 'Unknown'
                    )

                    self.e_machine_combo.set_title(
                        'ELF machine (auto-detect: %s)' % key
                    )
                    key = self.e_machine_combo.get_model().find(key)
                    if key is not None:
                        self.e_machine_combo.set_selected(key)

                    nonlocal is_64_bits

                    if not user_mod_trigger:
                        # Show guessed bitness

                        is_64_bits = self.kallsyms.is_64_bits

                        self.bitness_switch.set_title(
                            '64-bit (auto-detect: %s)'
                            % ('yes' if is_64_bits else 'no')
                        )
                        self.bitness_switch.set_active(is_64_bits)

                        self.guessed_bitness = is_64_bits

                        # Show guessed base address

                        if is_64_bits:
                            default_value = '%016x' % (
                                self.kallsyms.kernel_text_candidate or 0
                            )
                        else:
                            default_value = '%08x' % (
                                self.kallsyms.kernel_text_candidate or 0
                            )

                        self.base_address_entry.set_title(
                            'Base address, hexadecimal (auto-detect: %s)'
                            % default_value
                        )
                        self.base_address_entry.set_text(default_value)

                        self.guessed_base_address = (
                            self.kallsyms.kernel_text_candidate or 0
                        )

                    # Show "Detect symbols button" pointing to view #2

                    self.detect_symbols_bar.set_revealed(True)

                    # Display detected offsets in view #2

                    data = {
                        'input_file_start': 0,
                        'kallsyms_addresses_or_offsets': self.kallsyms.kallsyms_addresses_or_offsets__offset,
                        'kallsyms_num_syms': self.kallsyms.kallsyms_num_syms__offset,
                        'kallsyms_names': self.kallsyms.kallsyms_names__offset,
                        'kallsyms_markers': self.kallsyms.kallsyms_markers__offset,
                        'kallsyms_token_table': self.kallsyms.kallsyms_token_table__offset,
                        'kallsyms_token_index': self.kallsyms.kallsyms_token_index__offset,
                        'kallsyms_token_index_end': self.kallsyms.kallsyms_token_index_end__offset,
                        'elf64_rela_start': self.kallsyms.elf64_rela_start,
                        'elf64_rela_end_excl': self.kallsyms.elf64_rela_end_excl,
                    }

                    selection_model = self.offset_list_selection_model

                    list_store = selection_model.get_model()
                    selection_model.set_model(None)
                    list_store.remove_all()

                    for key, value in data.items():
                        if value is not None:
                            list_store.append(
                                DetectedTokenRow(
                                    token=key,
                                    offset='%08x' % value,
                                )
                            )

                    selection_model.set_model(list_store)

                    # Prepare to display hex dump reacting to
                    # clicking offsets in view #2

                    self.offset_selection_split_view.set_show_sidebar(False)

                    # Display address in view #3

                    selection_model = self.symbol_table_selection_model

                    list_store = selection_model.get_model()
                    selection_model.set_model(None)
                    list_store.remove_all()

                    fmt = '%016x' if is_64_bits else '%08x'

                    for symbol in self.kallsyms.symbols:
                        list_store.append(
                            RecoveredSymbolRow(
                                name=symbol.name,
                                type=symbol.symbol_type.name,
                                address=fmt % symbol.virtual_address,
                            )
                        )

                    selection_model.set_model(list_store)

                GLib.idle_add(update_ui_cb)

            finally:

                def hide_spinner_cb(*args):
                    self.selection_spinner_row.set_visible(False)

                    self.offsets_page.set_can_pop(True)
                    self.offsets_page.get_child().set_layout_name(
                        'offsets_page_layout'
                    )

                GLib.idle_add(hide_spinner_cb)

        thread = Thread(target=detection_thread)
        thread.daemon = True
        thread.start()


def main():
    logging.basicConfig(
        stream=stderr,
        # level=logging.DEBUG if args.verbose else logging.INFO,
        level=logging.INFO,
        format='%(message)s',
    )

    args = ArgumentParser(description='A GUI for the vmlinux-to-elf utility')
    args.add_argument(
        'input_file',
        help='An optional file to feed the tool with at startup',
        nargs='?',
    )
    args.add_argument(
        '--install-metadata',
        help=(
            'Install FreeDesktop metadata (.desktop + icon) to '
            + '$XDG_DATA_HOME, or ~/.local/share, or /usr/local/share '
            + 'if root'
        ),
        action='store_true',
    )
    args.add_argument(
        '--remove-metadata',
        help=('Revert the effects of --install-metadata'),
        action='store_true',
    )

    args = args.parse_args()

    if args.install_metadata or args.remove_metadata:
        from os import geteuid  # UNIX-specific

        if geteuid() == 0:
            xdg_path = '/usr/local/share/'
        else:
            xdg_path = join(environ['HOME'], '.local', 'share')

        xdg_path = expanduser(environ.get('XDG_DATA_HOME', xdg_path))

        icon_src = join(ASSETS_DIR, APP_ID + '.svg')
        metainfo_src = join(ASSETS_DIR, APP_ID + '.metainfo.xml')
        desktop_src = join(ASSETS_DIR, APP_ID + '.desktop')

        icon_dst = join(xdg_path, 'icons', APP_ID + '.svg')
        metainfo_dst = join(xdg_path, 'metainfo', APP_ID + '.metainfo.xml')
        desktop_dst = join(xdg_path, 'applications', APP_ID + '.desktop')

    if args.install_metadata:
        for src, dst in [
            (icon_src, icon_dst),
            (metainfo_src, metainfo_dst),
            (desktop_src, desktop_dst),
        ]:
            logging.info('[+] cp %r %r' % (src, dst))
            makedirs(dirname(dst), exist_ok=True)
            copy2(src, dst)

        logging.info(
            '[+] FreeDesktop metadata installed successfully to "%s"'
            % xdg_path
        )
        exit(0)

    elif args.remove_metadata:
        data_removed = False
        for path in [icon_dst, metainfo_dst, desktop_dst]:
            if exists(path):
                logging.info('[+] rm %r' % (path))
                remove(path)
                data_removed = True
        if data_removed:
            logging.info(
                '[+] FreeDesktop metadata removed from "%s"' % xdg_path
            )
            exit(0)
        else:
            logging.error('[!] No metadata present at "%s"' % xdg_path)
            exit(1)

    GLib.set_prgname(APP_ID)

    app = MyApp(
        application_id=APP_ID,
        flags=Gio.ApplicationFlags.NON_UNIQUE
        | Gio.ApplicationFlags.HANDLES_OPEN,
    )
    app.run(argv)


if __name__ == '__main__':
    main()
